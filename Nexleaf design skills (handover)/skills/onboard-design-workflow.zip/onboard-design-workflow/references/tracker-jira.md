# Adapter — Jira

Set `TRACKER_KIND` in ORG.md to **jira** to select this adapter. Requires the Atlassian MCP connector.

> **Verified live against a real Jira site, 2026-10-05.** The four read operations below were
> executed and their responses read back. The three write operations are documented from the tool
> schemas and have **not** been executed — exercise them with `ACCEPTANCE-CHECKLIST.md` box B2
> before trusting them.

## Before anything else — `cloudId`

**Every Atlassian call takes a required `cloudId`.** Omit it and the first call fails.

Pass the site hostname directly — `acme.atlassian.net` — which resolves. Only fall back to
`getAccessibleAtlassianResources` if that is rejected. Record it in `ORG.md` as `{{TRACKER_URL}}`
and pass `{{TRACKER_URL}}` as `cloudId` everywhere.

## The seven operations

| Operation | Call | Verified |
|---|---|---|
| `resolve_epic` | `searchJiraIssuesUsingJql`, `project = {{TRACKER_PREFIX}} AND issuetype = Epic AND summary ~ "<project>"`. Create with `createJiraIssue`, issuetype `Epic`, if nothing matches | ✅ read |
| `create_ticket` | `createJiraIssue` — `project` = `{{TRACKER_PREFIX}}`, `parent` = epic key, `labels` per the four axes | ⬜ untested |
| `comment` | `addCommentToJiraIssue` — markdown is converted to ADF by the connector | ⬜ untested |
| `transition` | `getTransitionsForJiraIssue`, **then** `transitionJiraIssue` **by id** | ✅ read half |
| `link` | `createIssueLink` issue-to-issue; a comment carrying the URL otherwise | ⬜ untested |
| `search` | `searchJiraIssuesUsingJql` | ✅ |
| `ticket_url` | **Do not build it** — every issue comes back with `webUrl` already populated | ✅ |

## Three things that are only obvious once you have run it

**1. The design-system log is probably a Task, not an Epic.** On the reference site, the
design-system running log is a *Task* parented to a *Product Design* epic — so a `resolve_epic`
that searches for `issuetype = Epic` will never find it and will helpfully create a duplicate.

Treat `{{TRACKER_OPS_EPIC}}` and `{{TRACKER_DS_EPIC}}` as **keys to resolve directly**, not names
to search for. Confirm each one's `issuetype` at onboarding and record it. Only `resolve_epic` for
*project* epics you are creating.

**2. Transition by id, never by name.** The reference site exposes `To Do` = `11`,
`In Progress` = `21`, `Done` = `31`. Names and ids both vary per project, and a guessed name fails
silently — the call returns, nothing moves. Always `getTransitionsForJiraIssue` first, match the
name you want, and send its `id`.

**3. `webUrl` is returned on every issue.** Do not hand-assemble
`https://<host>/browse/<key>`; read the field. One less thing to get wrong when the site moves.

## Field mapping

| Interface concept | Jira |
|---|---|
| project | project key `{{TRACKER_PREFIX}}` |
| epic | issuetype `Epic` (`hierarchyLevel: 1`) |
| ticket | issuetype `Task` or `Story` (`hierarchyLevel: 0`) |
| discipline | label `discipline:design` / `discipline:engineering` |
| surface | label `surface:design` / `surface:prototype` / `surface:both` |
| source | label `source:meeting` / `transcript` / `chat` / `verbal` / `prd` |

Labels come back as a plain array and were empty on the reference ticket — **Jira does not require
labels to pre-exist**, unlike GitHub. They can be applied on first use.

## Traps

- `getJiraProjectIssueTypesMetadata` tells you which issue types a project actually allows, before
  you try to create one that does not exist.
- Team-managed projects use `parent` for the epic relationship, not the legacy epic-link custom
  field.
- `searchJiraIssuesUsingJql` defaults to a limited field set. Pass `fields` explicitly, and include
  `comment` if you need comments — they are not returned otherwise.
