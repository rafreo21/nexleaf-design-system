# ORG.md — the only file you edit per organisation

Every skill in this plugin reads its organisation-specific values from here. Fill this in once
and the whole workflow follows. Nothing else in `skills/` should ever contain your company name,
file keys, or URLs.

Auto-load it by adding this line to the repo's `CLAUDE.md`:

```
@ORG.md
```

> Replace every `<...>` below. Leave a row blank only if the **Required** column says *optional*;
> a blank required value will cause a skill to guess, which is the failure mode this file exists
> to prevent.

---

## 1 · Identity

| Token | Required | Value | What it is |
|---|---|---|---|
| `{{ORG_NAME}}` | yes | `<Acme Health>` | Company name, as it should appear in prose and commit messages |
| `{{PRODUCT_NAME}}` | yes | `<SupplyTrack>` | The product this design workflow serves |
| `{{PRODUCT_SLUG}}` | yes | `<supplytrack>` | kebab-case form, used in filenames (`docs/<slug>-domain.md`) |
| `{{DESIGNER}}` | yes | `<Dana>` | The person whose corrections the skills accumulate. First name is fine |

## 2 · Design system

| Token | Required | Value | What it is |
|---|---|---|---|
| `{{DS_NAME}}` | yes | `<Orbit>` | The design system's name in conversation |
| `{{DS_LIBRARY_NAME}}` | yes | `<Orbit Design System v3>` | Exact Figma library name, as published |
| `{{DS_ALIAS}}` | yes | `<@orbit>` | The code import alias. `@ds` is a reasonable default |
| `{{DS_SPEC_FILE}}` | yes | `<OrbitDesign.md>` | The design system's own principles doc, at the repo root |

## 3 · Figma

| Token | Required | Value | What it is |
|---|---|---|---|
| `{{FIGMA_DESIGN_FILE_KEY}}` | yes | `<key>` | The product design file. From `figma.com/design/<KEY>/...` |
| `{{FIGMA_LIBRARY_FILE_KEY}}` | yes | `<key>` | The published component library file. **Must be a different file** — a library that lives in the design file cannot be versioned independently |

## 4 · Tracker

Set `{{TRACKER_KIND}}` to one of `jira` · `linear` · `asana` · `github-issues` · `none`, then
fill the rest. The matching adapter in `skills/onboard-design-workflow/references/tracker-<kind>.md`
defines what each field means for that tool.

| Token | Required | Value | What it is |
|---|---|---|---|
| `{{TRACKER_KIND}}` | yes | `<jira>` | Which adapter to load |
| `{{TRACKER_PROJECT}}` | yes | `<{{TRACKER_PROJECT}}>` | How to name the board in prose |
| `{{TRACKER_PREFIX}}` | yes | `<ACME>` | Ticket id prefix, so `ACME-23` reads correctly |
| `{{TRACKER_OPS_EPIC}}` | yes | `<ACME-7>` | The design-ops epic — workflow and system work |
| `{{TRACKER_DS_EPIC}}` | yes | `<ACME-8>` | The running log for design-system component work |
| `{{TRACKER_URL}}` | yes | `<acme.atlassian.net>` | Host AND the workspace identifier every call needs (Atlassian `cloudId`, Linear team, Asana workspace, GitHub `owner/repo`). Without it the first call fails |

`{{TRACKER_TICKET}}` appears in skill prose as a stand-in for "the ticket id" (what was `PD-XX`).
It is **not** a value you set here.

## 5 · Delivery surfaces

If the organisation has no prototype hub, set `{{HUB_PATH}}` to `none` and the onboarding skill
will disable stage 5 rather than leave it pointing at nothing.

| Token | Required | Value | What it is |
|---|---|---|---|
| `{{REPO_PATH}}` | yes | `<~/Documents/Design System>` | Where the repo lives on the designer's machine |
| `{{HUB_PATH}}` | optional | `<prototype-hub>` | Prototype hub directory, relative to the repo root. `none` to disable |
| `{{HUB_PROJECTS_PATH}}` | optional | `<prototype-hub/src/projects>` | Where hub projects are scaffolded |
| `{{DEV_HOST}}` | optional | `<localhost:3000>` | Local review URL — the one the designer always gets first |
| `{{TEAM_HOST}}` | optional | `<design.acme.com>` | Where reviewed work is published |
| `{{PREVIEW_PATH}}` | optional | `</prototype-hub-preview/>` | Auto-deploying preview path |
| `{{TEAM_PATH}}` | optional | `</prototype-hub/>` | Team path — publishes **only on approval** |
| `{{PREVIEW_URL}}` | optional | `<design.acme.com/prototype-hub-preview/>` | Full preview URL |

---

## 6 · What this file deliberately does NOT hold

Three things are organisation-specific but cannot be configured, only **generated**. The onboarding
skill produces each one; they are outputs, not settings.

| Artefact | How it comes to exist |
|---|---|
| `DESIGN-SYSTEM-INVENTORY.md` | Generated from `{{FIGMA_LIBRARY_FILE_KEY}}` — every component with its key and properties |
| `DESIGN-LAYOUT-CONTRACT.md` | Seeded from three reference frames the designer nominates, then amended as they correct it |
| `product-context` skill | Grown from the org's own docs, transcripts and live product. Starts as a skeleton |

And one thing that cannot be transferred at all: **the corrections log.** Every installation starts
with an empty "standing rules" section. That section is the part that compounds, and it is earned
one correction at a time. Do not copy another organisation's rules into it — they encode a different
product, a different library, and a different person's judgement.
