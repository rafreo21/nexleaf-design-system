---
name: "product-context"
description: "Working knowledge of how {{PRODUCT_NAME}} actually behaves - its real data model, hierarchy, enums, thresholds, permission model, known structural gaps, and the log of design decisions agreed so far. Load before writing or reviewing any PRD, spec, ticket or feature brief for {{PRODUCT_NAME}}; before designing any new screen or flow; whenever making a product judgement call or asked 'should we build X' or 'what am I missing'; and whenever a meeting, correction or agreed decision changes how the product works - so this file is updated in the same turn."
---

# {{PRODUCT_NAME}} - how it actually behaves

> **SKELETON.** Every heading below is a question this file must answer before the workflow can
> be trusted. Fill them from {{ORG_NAME}}'s own sources and **cite each one**. A value that cannot
> be traced to a source is a guess - say so, or go and read the real form.

## 1 · Who uses it

Roles, where they are, what device, what connection. The person standing in front of the thing.

## 2 · The hierarchy and the data model

The entities and how they nest. Get this wrong and every form invents a field that should have
been derived.

| Entity | Parent | Identified by | Notes |
|---|---|---|---|
| | | | |

## 3 · Enums - the real ones

**Never invent an option list.** Record each with its source: a screenshot, the live form, the API.

| Field | Values | Source |
|---|---|---|
| | | |

## 4 · Thresholds, windows and limits

Numbers the product enforces, and where each is enforced (client, server, policy). Note any that
the design and the live platform **disagree** on - that disagreement is a decision someone owes.

## 5 · Permission model

Who can see what, who can change what, and what a read-only user is shown instead.

## 6 · Known structural gaps

Things the product does not do that people assume it does. Record these so nobody designs against
a capability that is not there.

## 7 · Decision log

Append-only. One entry per agreed decision: the date, what was decided, who decided it, what was
rejected and why. Update in the same turn the decision is made.

### <date> - <decision>   [agreed]
- **Decision:**
- **Rejected:**
- **Why:**
- **Source:**
