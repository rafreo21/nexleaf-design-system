# Adapter — GitHub Issues

Set `TRACKER_KIND` in ORG.md to **github-issues** to select this adapter. Requires a GitHub MCP connector or `gh`.

| Operation | Call | Notes |
|---|---|---|
| `resolve_epic` | A tracking issue with a task list, or a Milestone | Pick one at onboarding and record it; mixing both is how work gets lost |
| `create_ticket` | Create issue, reference the tracking issue in the body | |
| `comment` | Create issue comment | |
| `transition` | Projects v2 Status field, or `status:*` labels | Open/closed alone is not a workflow |
| `link` | A comment with the URL; GitHub renders Figma links plainly | |
| `search` | Issue search with `repo:` and `label:` qualifiers | |
| `ticket_url` | `https://github.com/<owner>/<repo>/issues/<n>` | |

## Field mapping

| Interface concept | GitHub |
|---|---|
| project | Repository |
| epic | Tracking issue or Milestone |
| ticket | Issue |
| discipline / surface / source | Labels — create all twelve at onboarding |

## Traps

- Issue numbers are per-repo. `{{TRACKER_PREFIX}}` should be the repo name, and commits must carry
  `owner/repo#n` if design and engineering live in different repos.
- Labels must exist before they can be applied. Create them during onboarding, not on first use.
- Closing an issue from a commit message is an automation that will fight `transition`.
