# Adapter — Linear

Set `TRACKER_KIND` in ORG.md to **linear** to select this adapter. Requires a Linear MCP connector.

| Operation | Call | Notes |
|---|---|---|
| `resolve_epic` | List projects, match by name; create a Project if absent | Linear **Projects** are the epic analogue, not Milestones |
| `create_ticket` | Create issue with `projectId` set | |
| `comment` | Create comment on issue | |
| `transition` | Update issue `stateId` | Workflow states are per-team — resolve the team's states first |
| `link` | Issue attachments, or a comment carrying the URL | Linear attachments render Figma links with a preview |
| `search` | Issue search by text, scoped to the team | |
| `ticket_url` | `https://linear.app/<workspace>/issue/<id>` | |

## Field mapping

| Interface concept | Linear |
|---|---|
| project | Team |
| epic | Project |
| ticket | Issue |
| discipline / surface / source | Labels — create the three label groups once at onboarding |

## Traps

- `{{TRACKER_PREFIX}}` is the **team key** (`ENG`, `DES`), and ids are team-scoped.
- Linear auto-transitions issues on branch and PR activity. If engineering work is tracked here,
  `transition` may be fighting an automation — check before setting state by hand.
- There is no Epic type. Do not try to create one; use a Project.
