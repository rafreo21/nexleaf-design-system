# The tracker interface

Every skill in this plugin talks to the tracker through **seven operations only**. Nothing else.
If a skill needs something not on this list, the interface is wrong — extend it here rather than
calling a tool directly from the skill.

This is what makes the Track stage pluggable: swapping Jira for Linear is a new adapter file, not
a rewrite of `design-workflow`, `prd-to-tickets` or `prototype-review-then-publish`.

## The seven operations

| Operation | What it must do | Used by |
|---|---|---|
| `resolve_epic(project)` | Return the epic for a project, creating it if absent | `prd-to-tickets` |
| `create_ticket(epic, title, body, labels, discipline)` | New scope only. Returns an id | `prd-to-tickets`, `design-workflow` |
| `comment(ticket, body)` | Revisions, observations, corrections, reverts | every stage |
| `transition(ticket, state)` | Move to in-progress when work **starts**, not when it ends | `design-workflow` |
| `link(ticket, url, label)` | Attach a Figma frame, prototype URL or board | Create, Deliver |
| `search(query)` | Check something is not already filed before filing it | pre-flight |
| `ticket_url(id)` | Build a clickable link from an id | everywhere |

## The rules that hold across every adapter

These are workflow rules, not tool rules. They survive the swap.

1. **New scope = ticket. Observation, revision or correction = comment.** The most common mistake
   is filing a ticket for something that is a comment on an existing one.
2. **Search before filing.** Check the tracker *and* the repo *and* the Figma file. Three of four
   "missing component" tickets in the source installation were wrong.
3. **Transition on start.** A board where everything moves to in-progress at the moment it closes
   tells you nothing.
4. **If a change is reverted, say so on the ticket.** A comment describing work that no longer
   exists is worse than no comment.
5. **Labels carry four axes:** workflow, discipline (design or engineering), surface (design tool,
   prototype, or both), and source (meeting, transcript, chat, verbal, PRD). Adapters map these
   onto whatever the tool offers — labels, tags, custom fields, or title prefixes.

## Name the workspace identifier, or the first call fails

Nearly every tracker connector takes a required workspace/site/team identifier on **every** call —
Atlassian's `cloudId`, Linear's team, Asana's workspace, GitHub's `owner/repo`. It is invisible
until the first call returns an error, and it is the most common reason an adapter that reads fine
does not run.

Each adapter must state its identifier at the top, and `ORG.md` must carry it. Verified on the
Jira adapter 2026-10-05: the original version never mentioned `cloudId` and would have failed on
its first call at a new organisation.

## Resolve configured epics by KEY, not by searching for an epic

`{{TRACKER_OPS_EPIC}}` and `{{TRACKER_DS_EPIC}}` are identifiers the designer gives you. **Resolve
them directly.** Do not search for an epic whose name looks right — on the reference installation
the design-system log turned out to be a *Task* under a different epic, so a search for
`issuetype = Epic` would have found nothing and created a duplicate.

Confirm each one's actual type at onboarding, and record it. Only use `resolve_epic`'s search path
for *project* epics you are creating fresh.

## Writing a new adapter

Create `tracker-<kind>.md` in this directory answering, for each of the seven operations: which
tool call, what the arguments are, and what comes back. Then add `<kind>` to the allowed values of
`TRACKER_KIND` in `ORG.md`.

If the tool has no concept for one of the seven, say so explicitly and name the fallback. An
adapter that silently no-ops is how half a workflow appears to run.
