# Adapter — Asana

Set `TRACKER_KIND` in ORG.md to **asana** to select this adapter. Requires an Asana MCP connector.

| Operation | Call | Notes |
|---|---|---|
| `resolve_epic` | Find or create a **Section** within the project | Asana has no epic; a Section is the closest grouping |
| `create_ticket` | Create task in the project, assigned to the section | |
| `comment` | Add a story (comment) to the task | |
| `transition` | Set the custom field `Status`, or move between sections | Asana's native completion is binary — a Status custom field is required for a real workflow |
| `link` | Attach the URL to the task | |
| `search` | Typeahead search within the workspace | |
| `ticket_url` | `https://app.asana.com/0/<project>/<task>` | |

## Field mapping

| Interface concept | Asana |
|---|---|
| project | Project |
| epic | Section |
| ticket | Task |
| discipline / surface / source | Custom fields — create all three at onboarding, as enum fields |

## Traps

- **Asana has no ticket id prefix.** `{{TRACKER_PREFIX}}` is cosmetic; commit messages should carry
  the task URL instead, or ids will not resolve.
- Completion is a boolean. Without a Status custom field, "move to in-progress when work starts"
  cannot be expressed — say so at onboarding rather than silently skipping rule 3.
- Subtasks do not inherit custom fields. Keep workflow state on the parent task.
