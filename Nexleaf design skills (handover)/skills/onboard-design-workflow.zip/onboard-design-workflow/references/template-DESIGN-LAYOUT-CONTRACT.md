> **TEMPLATE.** Every `<ANGLE_BRACKET>` is a geometry value you must derive from three
> reference frames the designer nominates - never guess one, and never write a range.
> Every `{{TOKEN}}` comes from `ORG.md`. Delete this banner once filled in.

# DESIGN LAYOUT CONTRACT — binding on every session

**This file is the single source of truth for how a {{PRODUCT_NAME}} screen and a Figma board are laid
out.** It auto-loads via `CLAUDE.md`. Read it before drawing anything. If you deviate, you are
wrong — unless {{DESIGNER}} says otherwise, in which case **update this file in the same turn**.

Why it exists: two sessions built two boards to two different conventions. {{DESIGNER}}, 2026-08-27:
*"WE ARE NOT CONSISTENT… CONSISTENT IN DESIGN LAYOUT SHOULD BE UPDATED SO EVERY SESSION LEARNS FROM
IT."* Rules scattered across a long incident log are not a contract. This is.

---

## 1 · Desktop screen — <DESKTOP_W> × ≥<FRAME_MIN_H>

```
┌────────────────────────────────────────────────────┐
│ Top bar            <DESKTOP_W> × 56  @ 0,0                │  no line, no shadow, EVER
├────┬───────────────────────────────────────────────┤
│nav │  Page card    <CARD_W> × ≥<CARD_MIN_H>  @ 80,72            │
│ 56 │                                                │
│ ↕  │                                                │
│full│                                                │
└────┴───────────────────────────────────────────────┘
```

| Element | Geometry | Notes |
|---|---|---|
| **Top bar** | `<DESKTOP_W> × 56 @ 0,0` | **No divider, border or shadow.** The hairline is a `DROP_SHADOW 0,1 r0` — remove it. Constraints `STRETCH / MIN`. |
| **Side nav** | `56 × <frame height> @ 0,0` | `Closed Navigation`. **Full height, always.** Constraints `MIN / STRETCH`. Sits *below* the top bar in z-order. Re-resize on every frame resize. |
| **Page card** | `<CARD_W> × max(<CARD_MIN_H>, content + 32) @ 80,72` | A **slab, not a hug** — <CARD_MIN_H> minimum even when content is short. `72 = 56 top bar + 16`. |
| **Success card** | `<SUCCESS_W> @ 344,72` | Narrower, centred. Hugs its content. |
| **Modal** | `<MODAL_W>`, **vertically centred** | `y = (frame.height − modal.height) / 2`. Never pulled to the top. |
| **Frame height** | `max(<FRAME_MIN_H>, bottom-most visible child + 24)` | Count things *outside* the card too — toasts, below-card banners. |

**Match cards by exact width, never a range.** `width > 600 && width < 1000` catches modals and
wrecks them. <CARD_W> = page card · <SUCCESS_W> = success card · <MODAL_W> = modal.

**Always re-assert position after a resize.** `frame.resize()` moves children. Set `card.y = 72`,
resize, then set `card.y = 72` again.

## 2 · Layer order and the fixed / scrolls split

Bottom to top in `frame.children`:

```
[ page content, __dropdown, __contact_tags, below-card banner ]   SCROLLS
[ Top bar, Closed Navigation ]                                     FIXED
[ Loader, Overlay, Scrim, Modal, Toast ]                           FIXED
frame.numberOfFixedChildren = chrome.length + overlays.length
```

There is **no `scrollBehavior` property** in this runtime — reading it throws. Use
`numberOfFixedChildren`, which fixes the *last N children in the array* (= top N in the layer panel).

Anchored things (`__dropdown`, `__contact_tags`) stay in **scrolls** — they travel with their field.
Modals sit above the chrome so they dim the top bar.

## 3 · Breadcrumb — the collapse rule

Spec sheet `<BREADCRUMB_SPEC_NODE>`. **The leading node is an icon, never a text crumb reading "Home."**

| Levels | Renders | Properties |
|---|---|---|
| 1 | `[icon]` | all false |
| 2 | `[icon] › Label` | `Crumb 2` |
| 3 | `[icon] › Label › Label` | `Crumb 2` + `Crumb 3` |
| **>3** | `[icon] › Label › … › Label` | `Crumb 2` + **`Page List`** + `Crumb 3` |

Past three levels the **middle collapses into `…`**. `Crumb 1` (text Home) stays **false** on this
product. Every chevron is bound to the crumb that follows it, so hiding a crumb never leaves a
dangling `›`.

## 4 · Mobile screen — <MOBILE_W> × ≥<MOBILE_MIN_H>

| Element | Geometry |
|---|---|
| Status bar | `<MOBILE_W> × 44 @ 0,0` — always |
| Mobile Top Nav | `<MOBILE_W> × 52 @ 0,44` — **secondary pages only** |
| Content column | `x = 16`, width `<MOBILE_COL_W>` |
| Card padding | `0 / 16 / 0 / 16` → children **<MOBILE_CHILD_W>** |
| Column `y` | **52** tertiary (wizard step, no nav) · **172** secondary · **198** secondary + toast |
| Frame height | `max(<MOBILE_MIN_H>, column bottom + 24)`; with a sheet, `max(<MOBILE_MIN_H>, sheet + 96)` |

- **Shell level decides the nav.** Tertiary = has a wizard stepper = **no Mobile Top Nav**, back
  arrow in the header. Derive from content, never from the frame-code prefix.
- **Column constraints `MIN / MIN`.** Inherited `CENTER/CENTER` is what made columns drift on every
  refit. Chrome is `STRETCH / MIN`.
- **A phone frame is <MOBILE_MIN_H> and the page behind a sheet clips.** Never stretch the frame to fit the
  page. Sheets pin to the bottom. Paginate rather than grow.
- Modals become **bottom sheets**. Review rows **stack** (label above value).
- Every desktop state has a mobile twin, or the set is incomplete.

## 5 · Board layout — sections, rows, journey order

```
SECTION  "<Flow name>"
  content                    ← flow intro card, top-left
  § Happy path               ← group heading (TEXT)
  A1  A2  A3  A4  A5         ← screens in CODE order, 5/row desktop · 8/row mobile
    ↳ note · A1              ← annotation, 16px under its screen, same x
  A6  A7  A8  A9
  § Variants
  § Edge cases
```

Groups run **happy path → variants → edges**. That ordering *is* the journey.

Spacing: `PADX 64 · PADY 112 · COLGAP 80 · ROWGAP 140 · NOTEGAP 16 · HEADGAP 28 · GROUPGAP 180 ·
INTROGAP 120`. Row wrap by **width budget** (`64 + 5×<DESKTOP_W> + 4×80` desktop, `64 + 8×<MOBILE_W> + 7×80`
mobile), not a fixed count.

- **Sort screens by semantic code, never by canvas position.** Sorting by `(y, x)` scrambles the
  order on every re-run.
- **Section width = widest row**, not the last row. Getting this wrong sizes sections far too small
  and frames render outside their own boundary.
- Mobile section sits at `desktop.x + desktop.width + 600`, same `y`. Section pairs stack with 500.
- **Never bulk-operate on a section you don't own.** Build an explicit allow-list; skip any section
  carrying `getSharedPluginData('{{ORG_NAME}}.parity','owner')`.

## 6 · Annotation — every state, tone-matched

**Every state frame carries a `note · <CODE>` frame. No exceptions, both viewports.**

- Directly beneath its screen: same `x`, `y + height + 16`. **440** wide desktop, **<MOBILE_W>** mobile.
- **Fill carries the tone of what it describes:** `ℹ` info `#EAF4FF` · `⚠` warning `#FFF1E3` ·
  `⛔` critical `#FEE9E8`. An error state never gets a blue note.
- **Per-state notes use the short form** — tone glyph + a short statement of what the screen *is*.
  Decided 2026-08-27: scannable at board zoom, and the glyph carries the state class instantly.
- **The structured `WHEN IT APPEARS: / PURPOSE: / WHAT IT DOES:` block belongs to the section
  `content` intro card only**, not to per-state notes. Its value is the flow-level explainer.
- Body answers **when it appears · what it's for · the rule it carries** — the commit boundary, why a
  control is a dropdown and not free text, what recovery exists. Never a restatement of the title.
- **One `note · matrix` per section** declaring which of the 12 states were deemed N/A and why.
  Absence must be a decision on the canvas, not an omission.

## 6b · HOW TO BUILD A FRAME — the sequence, in order

Consistency is not a review step, it's a build order. Every drift this project has suffered came
from doing these out of sequence. Follow it literally.

### 1 · Never start from a blank frame
Clone the nearest **reference frame** (registry at the end of `FIGMA-MAP.md`) or an existing sibling
screen, then change only what this state changes. Building from a spec's field list produced 24
frames that were thrown away. If no sibling exists, clone the frame family's canonical example.

### 2 · Establish the family and the chrome first
Decide page card (<CARD_W>) · success card (<SUCCESS_W>) · modal (<MODAL_W>). Set geometry from §1 **before** adding
content, so content lays out into a correct box rather than being nudged afterwards.

### 3 · Compose from real instances, by key
```js
const set = await figma.importComponentSetByKeyAsync(KEY);   // keys: DESIGN-SYSTEM-INVENTORY.md
const inst = set.children.find(v => v.name === 'State=rest, …').createInstance();
parent.appendChild(inst);
```
Check the inventory first. Never hand-roll, never substitute a lookalike (`Badge` is not `Tag`).

### 4 · Set text through component properties, never `.characters`
Assigning `.characters` to a property-driven node **silently does nothing**. Keys carry a literal
`↪️ ` prefix, so resolve by regex:
```js
const keyOf = (n, re) => Object.keys(n.componentProperties || {}).find(k => re.test(k));
inst.setProperties({ [keyOf(inst, /Label content/)]: 'Submit' });
```

### 5 · Append before sizing
`layoutSizingHorizontal = 'FILL'` only works once the node is already a child of an auto-layout
frame. Append first, then size.

### 6 · Respect instance boundaries
A node whose id contains `;` is instance-nested: you may set properties and `layoutSizing`, but
`resize`, `remove` and `appendChild` all throw. To place content "inside" a component with no slot,
**overlay a sibling frame** positioned over it — and log the missing variant as a DS gap. (`.slot
examples` frames *do* accept real instances.)

### 7 · Assert clones actually render
Cloning a hidden or transparent source yields a hidden clone, and the script reports success. Set
`visible = true` and `opacity = 1` on the clone **and its descendants**, then read the size back. 84
invisible buttons and 52 invisible badges were shipped this way.

### 8 · Name every structural node you create
`__contact_tags`, `__contacts_pager`, `__dropdown`, `__step_counter_row`. Later passes then target
**by name**, never by counting parents — counting parents deleted the contents of five rows and left
the shells behind.

### 9 · Refit in this exact order
```
1. hug the inner stacks            col.layoutSizingVertical = 'HUG'
2. set card geometry               card.x/y per §1 (card height = max(<CARD_MIN_H>, content+32))
3. resize the frame                max(<FRAME_MIN_H>, bottom-most visible child + 24)
4. RE-ASSERT the card position     resize moves children — set card.y again
5. resync full-bleed overlays      Loader/Overlay/Scrim → 0,0 and frame size
6. re-pin bottom sheets            sheet.y = frame.height − sheet.height
7. resize the side nav             56 × frame.height
```
Skipping step 4 is what produced the dead band above E1. Skipping 5 clipped six Loaders.

### 10 · Pin constraints so nothing drifts
Content column / card `MIN / MIN` · chrome `STRETCH / MIN` · side nav `MIN / STRETCH` · modals
`CENTER / CENTER`. Inherited `CENTER/CENTER` on a column is the single biggest cause of repeat drift.

### 11 · Read it back, then count
Normalise whitespace before matching text — Figma text contains non-breaking spaces (char 160), and
a naive regex silently matches nothing:
```js
const norm = s => String(s).replace(/[\u00a0\u2007\u202f]/g, ' ');
```
A plugin run that throws **rolls back the entire run**, so re-read state after any failure rather
than assuming a partial apply. Never trust a returned success value.

### 12 · Reflow the board, then run the five numbers
Reflow per §5 (sort by code, section width from the *widest* row), then report §7.

### Bulk passes — the guardrail
Any loop that repositions, resizes or re-pads is destructive to everything it touches. Build an
**explicit allow-list**; skip any section carrying
`getSharedPluginData('{{ORG_NAME}}.parity','owner')`; iterate **every child type**, not just frames; and
print the target list and count before writing. There is no undo.

## 6c · The flow specification — the written half

A board shows what a flow looks like. It cannot carry **why**, the rules, or what the design costs
engineering — so those live in a written spec, one per project, with no screenshots. It must be
readable by Ednah and by engineering without opening Figma.

```
docs/flows/<project>.md        source of truth — versioned, diffable, reviewed in PRs
Google Doc                     generated from it, shared, commentable
project.js  spec: / specSource: link both, so the hub surfaces it
```

Per flow, in this order: what it is and who for · entry points · preconditions · **happy path**
(what they see · what they do · what the system does · **where the commit boundary is**) · sad paths
with recovery · edge cases and limits · first run · **rules as testable statements** · **why it is
designed this way, naming what was rejected** · **engineering constraints split into *with* and
*against* current capability** · open questions with who decides · traceability.

Two sections earn their keep and are usually the ones missing:

- **Why, with the rejected alternative.** "Why is the sensor a dropdown and not free text" currently
  lives in a note on one frame. A reviewer should not have to open Figma to find it.
- **Against current capability.** Naming what the platform cannot do today — and what is merely
  *assumed* to work — is what stops a design being costed as though it were free.

**Every step names its prototype state id and Figma frame code.** That is what makes the spec
checkable rather than prose: doc, board and prototype can be diffed against each other.

**Authority when they disagree:** the board wins on layout and copy · the spec wins on rules and
rationale · the code wins on how a component behaves. Fix the one that is wrong, and say which.

Regenerate the Google Doc from the markdown; never edit the Doc as the source, or the repo copy
silently rots.

**One tab per section, and the Drive connector cannot make them.** `create_file` writes a doc's body
once; `update_file` only renames and moves. Neither knows about tabs. That is a limit of the
connector, **not a limit on what can be done** — and saying "it can't be done" when the right answer
is "that tool can't" is the mistake. The browser can:

1. Split the markdown at `^# ` into one file per section (`docs/flows/<project>-tabs/`), and convert
   each to HTML (`python3 -m markdown`, extensions `tables,fenced_code,sane_lists`).
2. Open the Doc in Chrome. `+` beside **Document tabs** adds a top-level tab; repeat for the count.
3. Per tab — click the row, click its `⋮`, press **Down ×4 → Return** (that lands on *Rename*
   regardless of whether the menu opened up or down, so no coordinate guessing), `cmd+a`, type the
   name, `Return`.
4. Click into the body, `cmd+a`, `Delete`, then paste the section by dispatching a synthetic
   clipboard event at Docs' hidden input — this is what carries real headings, tables, lists and bold:

```js
window.__paste = function (html) {
  const idoc = document.querySelector('.docs-texteventtarget-iframe').contentDocument;
  const t = idoc.querySelector('[contenteditable=true]') || idoc.body;
  const dt = new DataTransfer();
  dt.setData('text/html', html);
  dt.setData('text/plain', html.replace(/<[^>]+>/g, ' '));
  const ev = new ClipboardEvent('paste', {clipboardData: dt, bubbles: true, cancelable: true});
  t.dispatchEvent(ev);
  return ev.defaultPrevented;          // true = Docs handled it
};
```

`navigator.clipboard.write()` fails here — *Document is not focused* — so do not reach for it.
Rename + clear + paste fit in **one `browser_batch` per tab**.

Verify by reading the Doc back through the connector, not by trusting the paste's return value. Its
markdown rendering escapes bold inside table cells as `\*\*text\*\*`; that is the serializer, not the
document — confirm with a zoomed screenshot before "fixing" it.

## 7 · Definition of done — five numbers, every time

```
Frames        132 (66 desktop + 66 mobile)
Annotated     132/132        Notes placed 132/132
Matrix        11/12 drawn · 1/12 declared on canvas
Viewport      no gaps
Registry      33/33 bound, 0 unbound
```

Never report "looks complete". **A rule that nothing checks is a wish** — every rule above has an
assertion, and the numbers get reported.

## 8 · Composition

- **Never build a component from scratch.** Check `DESIGN-SYSTEM-INVENTORY.md` (82 components) first.
- `Tag` for chips — **never `Badge`**. `Cell` for list rows. `Pagination` for paging.
- When Figma and code disagree, **read the code first** — it has been right every time.
- Bind colour variables, but **read the resolved value back**: a variable whose name matches your
  intent may not carry the value your component needs.

---

## How to amend this contract  — every session, same rules

This file is shared by several concurrent sessions working in one repo. Amend it, don't fork it.

**0 · First, work out whether you *can* amend it.** Not every session has this repo.

| Surface | Can read the contract? | Can amend it? |
|---|---|---|
| **Cowork** with the `Design System` folder connected | **not automatically** — see below | **yes** — read, edit, commit |
| **Claude Code** launched inside this repo | yes, auto-loads | **yes** |
| **claude.ai chat / mobile** | **no** — sandboxed container, no `~/Documents` | **no** |
| Cowork **without** the folder connected | no | no |

**Cowork does not follow `@` imports.** Verified 2026-08-27: a Cowork session is given the *text* of
`CLAUDE.md`, including the literal `@DESIGN-LAYOUT-CONTRACT.md` lines, but the referenced files are
**not expanded into context**. Claude Code does expand them. So in Cowork you must `Read` this file
explicitly before relying on it — knowing the filename is not knowing the rule.

**Cheap test for any session claiming to have loaded it:** ask it to quote §7's five numbers back. If
it can't, it hasn't read the file.

If you cannot reach the file, **say so plainly instead of confirming you have read it**, and do not
pretend the same-turn duty applies. Instead, **emit the amendment as a ready-to-paste block** —
the exact section, the exact wording — so {{DESIGNER}} can carry it to a session that can write it. A
correction that can't be committed must at least be transportable. Never silently drop it.

**0b · Check the branch before trusting this file.** Auto-loading proves a file was read, not that
it is current. `main` has been weeks behind the working branch. Run `git branch -vv` and
`git log --oneline origin/main..HEAD | wc -l`. If you are on a branch that is behind, the contract
you just loaded is stale — say so rather than building to it.

**1 · Pull first.** Other sessions commit here. `git pull --rebase` before you edit, or you will
hand {{DESIGNER}} a merge conflict.

**2 · Amend in the same turn as the correction.** The moment he corrects something — a size, a
colour, a copy rule, a component choice — write it into the right numbered section here *before*
you reply. A correction that only lives in a chat transcript is lost.

**3 · Add the assertion, not just the prose.** Every rule here must be checkable in a sweep, and the
number reported. *A rule that nothing checks is a wish.* If you can't express it as an assertion,
say so in the entry.

**4 · Edit the section that owns it.** Screen geometry → §1. Layer order → §2. Breadcrumb → §3.
Mobile → §4. Board layout → §5. Annotation → §6. Build order → §6b. Done-ness → §7. Composition →
§8. **Never append a competing "rules" section at the bottom**, and never start a second contract
file — that is how the two boards diverged in the first place.

**5 · Long-form goes elsewhere.** This file states the rule. The war story, the API trap and the
diagnosis belong in `FIGMA-MAP.md`; component keys and properties in
`DESIGN-SYSTEM-INVENTORY.md`; product behaviour in `docs/{{PRODUCT_NAME}}-domain.md`. Keep this one short
enough to read before drawing.

**6 · Retract explicitly.** If a rule written here turns out to be wrong, replace it *and say it was
wrong*, with the date. Do not quietly delete — someone built to it.

**7 · Skills are gitignored.** `.claude/` is in `.gitignore`, so a skill change needs
`git add -f .claude/skills`. If you edit or add a skill, commit it, or the next session and Claude
Code will not see it.

**8 · Commit convention.** `docs(contract): <what changed> [PD-xx]`, and note it on the ~~project tracker ticket
that prompted it.

**9 · If a rule here conflicts with what {{DESIGNER}} just told you, he wins** — then update this file to
match, in the same turn.

## Two skill stores — name which one a rule governs

A rule about "skills" that doesn't say *which store* will misfire: someone will symlink a repo path,
or `git add -f` a home-directory path, and both fail confusingly.

| | Path | Follows | In the repo? |
|---|---|---|---|
| **User-level** | `~/.claude/skills` | the **account** | no — **never `git add` this path** |
| **Project-level** | `<repo>/.claude/skills` | the **directory** | yes, but **gitignored** — needs `git add -f .claude/skills` |

**Project-level skills load for any account that `cd`s into the repo.** A second config directory
isolates **credentials only** — project memory and project skills follow the directory, not the
account.

### The duplication hazard (user-level)

`cp -r ~/.claude ~/.claude-personal` creates a second independent copy of the **user-level** skills
that drifts silently — the same two-sources-of-truth failure this contract exists to prevent, one
layer down. Share by symlink instead of copying:

```sh
diff -rq ~/.claude/skills ~/.claude-personal/skills   # silence = safe to replace
rm -rf ~/.claude-personal/skills                      # NO trailing slash
ln -s  ~/.claude/skills ~/.claude-personal/skills
```

**Footgun:** once that path is a symlink, `rm -rf ~/.claude-personal/skills/` **with** a trailing
slash follows the link and deletes the real user-level skills. No trailing slash.

### Assertion — carried amendments must land

An amendment emitted by a no-filesystem session and never committed is a wish, same as an unchecked
rule. Audit periodically:

```sh
git log --grep='docs(contract)' --oneline     # against the PD refs on the ~~project tracker tickets
git status --ignored                          # project-level skill changes hiding behind .gitignore
```

Credit: a parallel claude.ai session caught both the impossible amendment duty and the conflated
skill stores. Corrections from a session that cannot commit are still worth acting on.

## Settled decisions — 2026-08-27

### Soft tints: the code is right, the library is missing a tier

`src/tokens/index.js` already defines **two deliberate tiers**, and documents why:

```
BG_INFO       = '#eaf4ff'   // banner / surface tier
BG_INFO_BADGE = '#e0f0ff'   // "a touch deeper ... better contrast of the chip against white"
```

Every library `fill-*-secondary` variable resolves to the **deeper chip tier** — `#e0f0ff`,
`#fedad9`, `#ffef9d`. Binding a 32px icon tile to them is reaching for the wrong tier, not
correcting a wrong value. A tile is a surface, not a chip.

**Decision:** no change to `Cell.jsx`. The library gains **soft-surface variables** at the code's
values, and `Cell` binds to those once they exist:

| tone | soft surface (code) | chip tier (existing library) |
|---|---|---|
| success | `#cdfee1` | — |
| critical | `#fde2e1` | `#fedad9` |
| warning | `#fff3cd` | `#ffef9d` |
| info | `#eaf4ff` | `#e0f0ff` |
| neutral | `rgba(0,0,0,0.06)` | `fill-transparent-secondary` — **resolves opaque, a library bug** |

Until the variables exist, `Cell`'s five tone tints stay **raw** and match `ICON_TONES`. Two library
tickets track the gap.

### Annotation format: short form for states, structured for the section

See §6. Per-state notes are the tone-glyph short form; the `WHEN IT APPEARS` block is for the
section intro card. The Manual Temperature Recording board's per-state notes condense to the short
form; Add Equipment's 132 already comply.

### Amendment windows: recommended, awaiting Ednah

Product policy with compliance implications, so **not** settled by design alone. The reasoning, for
whoever takes it to her:

- **Count both windows from the reading's date, not the save time.** Otherwise recording late
  silently extends your own amendment window — a two-week-old reading becomes editable by entering
  it yesterday. Counting from the date makes both windows tamper-proof.
- **Inclusive boundaries.** Day 7 is the last day you can record. Easier to explain than an
  exclusive cutoff.
- **Audit entry yes, free-text reason no.** Who, when, old → new, visible to supervisors and above.
  Cold-chain data feeds compliance reporting, so a silent edit is a data-integrity hole — but a
  mandatory reason field on a phone task produces junk.
- **Supervisor override on the 3-day amendment; none on the 7-day recording.** Amending stale data
  is a supervised correction. Creating readings for dates more than a week old is fabrication, and
  the system should offer no path to it.
