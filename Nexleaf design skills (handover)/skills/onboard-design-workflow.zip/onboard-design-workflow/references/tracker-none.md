# Adapter — none

Set `TRACKER_KIND` in ORG.md to **none** to select this adapter. For an organisation with no tracker, or a pilot that has not picked one.

**Do not silently skip the Track stage.** Losing the record is how a workflow stops compounding:
the decisions, the reverts and the reasons all live in tracker comments. Instead, write them to
a file.

| Operation | Behaviour |
|---|---|
| `resolve_epic` | Create `docs/decisions/<project>.md` if absent |
| `create_ticket` | Append a `## <date> — <title>` section with body and labels. The id is the heading anchor |
| `comment` | Append a dated bullet under the relevant heading |
| `transition` | Update a `status:` line in the heading block |
| `link` | Add the URL as a bullet |
| `search` | Grep the decisions directory |
| `ticket_url` | A relative path plus anchor |

## What is lost, and say so out loud

- No assignment, no notification, no cross-team visibility.
- No query across projects — "what is open" means reading every file.
- Two people editing the same decision file will conflict in git.

At onboarding, state these plainly and recommend adopting a real tracker before the second project.
This adapter is a bridge, not a destination.
