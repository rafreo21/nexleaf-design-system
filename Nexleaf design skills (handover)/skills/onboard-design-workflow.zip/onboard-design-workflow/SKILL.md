---
name: "onboard-design-workflow"
description: "Set up the design workflow for a new organisation, product or design system. Run this once per installation, before any other skill in this plugin. Use when someone says \"set up the design workflow\", \"onboard us\", \"configure this plugin\", \"ORG.md\", \"adapt this to our design system\", or when any skill reports that ORG.md is missing or still contains unfilled placeholders. It interviews for the configuration, writes ORG.md, picks the tracker adapter, then generates the three artefacts that cannot be copied: the design system inventory, the layout contract, and the product context skill."
---

# Onboard the design workflow

**The user-facing checklist and the copy-paste prompt for every stage live in `START-HERE.md`.**
Point people there rather than describing the stages in chat. If someone is running a single
stage, they will say so ("stage 3a") - do only that stage and stop.

**Stage 1 writes `ORG.md`. Stage 1b RUNS `scripts/apply-org.py --write`.** Tokens are dead text
until that script runs: a skill description is injected into the system prompt verbatim, before
any body or `ORG.md` is read, so `{{TOKEN}}` there can never resolve on its own. Never hand over
an installation where the script has not been run and verified.

Run this once per organisation. It turns a generic plugin into a workflow that knows *this*
company's design system, *this* product and *this* tracker.

**Three layers, three different treatments.** Understand which layer a thing belongs to before
touching it:

| Layer | What it is | How it is handled |
|---|---|---|
| 1 · Engine | The Figma skills, `product-os`, the PRD writers | Ships as-is. Nothing to do |
| 2 · Configuration | ~20 constants: file keys, tracker, URLs, names | **Interview → `ORG.md`** |
| 3 · Knowledge | Component inventory, layout contract, product behaviour | **Generated** from their Figma and their docs |

The corrections log is a fourth thing: it starts empty and is earned. Never copy one.

---

## Stage 0 · Check what already exists

Do not interview for things you can read. Before asking anything:

- Is there an `ORG.md`? If it exists with real values, this is a **re-run** — show the current
  config and ask what changed, rather than starting over.
- Is there a `CLAUDE.md`? Read it; it may already name the design system and the repo layout.
- Is there a `package.json`? The import alias, the dev server port and the framework are in there.
- Is a Figma MCP connected? A tracker MCP? Check before recommending one.

State what you found and what is still unknown. Then interview only for the gaps.

## Stage 1 · Interview → `ORG.md`

Copy `templates/ORG.md` to the repo root and fill it in. Ask in four short rounds, not one
long form. Confirm each round before moving on.

1. **Identity** — organisation, product, product slug, the designer's name.
2. **Design system** — its name, the exact published Figma library name, the code import alias,
   and the filename of its principles doc.
3. **Figma** — the design file key and the **library** file key. These must be two different
   files; if they are the same, stop and explain why that blocks independent versioning before
   continuing.
4. **Tracker and delivery** — which tracker, the project and epic ids, and the three delivery
   URLs. If there is no prototype hub, set `{{HUB_PATH}}` to `none`.

Then add `@ORG.md` to `CLAUDE.md` so every session loads it.

**A blank required value is a failure, not a default.** If the designer does not know a Figma file
key, go and find it rather than leaving a placeholder — a skill that hits `<key>` will guess.

## Stage 2 · Wire the tracker

Read `references/tracker-interface.md` — the seven operations every adapter must provide — then
load the adapter matching `{{TRACKER_KIND}}` from `references/tracker-<kind>.md`.

Create whatever the adapter says must exist before first use: the two epics, the label or custom
field groups, the workflow states. **Create them now.** Labels that do not exist cannot be applied,
and that failure surfaces three weeks later as an unfiled ticket.

If the tracker cannot express one of the seven operations, say so plainly and name the fallback.
Do not let an adapter silently no-op.

## Stage 2b · Study the reference installation

`reference/` holds one organisation's mature installation after about four months of real use.
**Read the file matching whatever you are about to produce, before you produce it.**

| Producing | Study |
|---|---|
| the layout contract | `reference/layout-contract.md` |
| the standing-rules section | `reference/standing-rules.md` |
| a flow specification | `reference/flow-spec.md` |
| the component inventory | `reference/inventory-format.md` |
| anything touching the design canvas | `reference/failure-modes.md` |

**Mimic the form. Never carry the content across.** Every geometry value, component name and rule
in there belongs to a different product. A rule copied from the reference is a rule this
organisation did not earn and cannot defend, and it will be trusted anyway - which is worse than
having no rule.

The exception is `reference/failure-modes.md`. Those five describe how an assistant fails at this
work, not anything about a product, so adopt them on day one. Write them into this organisation's
own contract in its own words.

When the designer asks "what should this look like?", show them the reference file rather than
describing it. It is faster and it sets the bar.

## Stage 3 · Generate the knowledge layer

These three are *outputs*, not settings. Produce them in this order — each depends on the last.

### 3a · `DESIGN-SYSTEM-INVENTORY.md`

Load `figma-use`, then read `{{FIGMA_LIBRARY_FILE_KEY}}`. For every published component record:
name, key, variant properties with their values, and which code component it maps to.

Then run `figma-create-design-system-rules` against the codebase to produce the composition rules.

This file is what stops the binding rule from being a wish. Without it, "never build UI from
scratch" has nothing to check against, and every session will re-derive — or invent — the
component set.

**Verify by count.** Report components found in the library versus components mapped to code, and
name the unmapped ones. Do not report a number you did not read back.

### 3b · `DESIGN-LAYOUT-CONTRACT.md`

Ask the designer to nominate **three reference frames**: a desktop screen they consider correct,
a mobile screen, and one modal or overlay. Read their actual geometry — do not ask for numbers.

From those three, derive and write down: chrome dimensions and position, the page card's width
and offsets, the minimum frame height, the modal width and vertical placement, the mobile column
x and width, and the layer order. Record each as an exact value, never a range.

> A range is how a sweep damages a board. `width > 600 && width < 1000` matches modals as well as
> cards. Match exact values and build explicit allow-lists.

Add the board conventions — sections, journey order, annotation placement and tone — and the
definition of done. `templates/DESIGN-LAYOUT-CONTRACT.md` carries the structure with the geometry
blanked.

Mark the file binding, and state that it is amended in the same turn as any correction.

### 3c · The `product-context` skill

Create a skill named `product-context` holding how the product *actually behaves*: the data model
and hierarchy, the real enums and their values, thresholds, the permission model, and the known
structural gaps.

Seed it from the org's own sources — their documentation, a recorded walkthrough of the live
product, meeting transcripts. **Record where each fact came from.** A value that cannot be traced
to a source is a guess, and inventing an enum is the single most expensive mistake this workflow
has seen: six option lists invented in one session, every one wrong, caught only when the designer
sent screenshots of the real dropdowns.

Start it as a skeleton with the headings and a stated gap list. It grows.

## Stage 4 · Prove it works end to end

Do not declare onboarding complete on configuration alone. Run one small real flow:

1. Create a ticket through the adapter, and read it back.
2. Compose one screen from the inventory, in code and on canvas.
3. Run `design-critique` and `figma-design-audit` over it.
4. Deliver it to the local URL.

Then report, honestly:

- components in the library vs mapped to code, and which are unmapped
- the five geometry values derived, and which frame each came from
- tracker operations exercised, and which are still untested
- **what you did not verify**

A returned success value is not proof. Read it back.

## Stage 5 · Hand over

Tell the designer, in plain language:

- `ORG.md` is the only file they edit when something changes
- the inventory is regenerated when the library is republished, not edited by hand
- the contract is binding, and **every correction they give must be written into it in the same
  turn as the fix** — that loop is the entire value of the system
- their standing-rules section is empty today, and that is correct

---

## What to say if the prerequisites are not met

**No component library in both Figma and code.** The binding rule has no referent. Say so directly:
this workflow's core discipline degrades into ordinary mockup work. Offer `figma-generate-library`
to build the library first, and treat that as the real project.

**Library and design file are the same file.** Components cannot be versioned or published
independently. Fix before onboarding.

**No tracker.** Use the `none` adapter, and recommend adopting one before the second project.
State what is lost rather than quietly dropping the stage.
