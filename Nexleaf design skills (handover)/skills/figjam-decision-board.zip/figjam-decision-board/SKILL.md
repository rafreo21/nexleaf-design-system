---
name: "figjam-decision-board"
description: "Turn scattered inputs (a meeting, docs, the live product, real data, a teammate's board) into one zoned FigJam flow + decision board before Figma mockups or a PRD. Carries the FigJam/use_figma mechanics that keep it from breaking."
---

# FigJam decision board (research to board, before Figma)

Use this to turn raw thinking inputs into ONE comprehensive FigJam board that externalises a whole feature before any Figma mockups. It slots into nexleaf-design-workflow between collect and create: the board is the shared thinking artifact the team reviews and marks up, and the source the PRD and mockups are built from.

## When to use
- A new feature where the flow, constraints and open questions are not settled yet.
- You have scattered inputs (Slack, a doc, a meeting, live product behaviour, data, a teammate's board) and need one place that holds all of it.
- Before Figma mockups or a PRD.
Do NOT use for pure UI mockups (that is Figma + the design system, ds-components-only) or for a settled feature that just needs screens.

## 1. Gather and extract
Pull every source into notes first. Typical sources: the reference doc, the meeting or transcript, the LIVE product (walk the real screens, do not assume), the data (real volumes, not the model in a sheet), a teammate's board, any analysis doc. There is no Mural connector, so read Mural via browser or screenshots and rebuild in FigJam. Extract into four buckets:
- Confirmed decisions (who confirmed, and why).
- Hard constraints (platform rules, device/firmware limits, policy).
- Real behaviour + data (how it works today, real numbers).
- Open questions (what still needs a decision, and who owns it).

## 2. Board structure (zones)
One board, zoned and titled, so it reads as a single artifact:
- Title + how-to-read + colour legend, top-left.
- A - Flow: the end-to-end user flow, split into lanes (e.g. opt-in / messaging / opt-out), one section per lane, laid out as a real flowchart.
- B - Reference: inventory (every item mapped), a decision table, content/message drafts.
- C - Technical & integration: platform/eng needs, how it fits the existing system, hard constraints.
- D - Failure modes / sad paths: scenario to response table.
- E - Use cases / journeys.
- F - In-product: where the design lands in the real product (which screens change, new components, effect on the current system, per user type).
- Sticky cards: Confirmed (source-attributed), Open decisions (with owners), Next steps, Tiers/keys.
Colour code with a legend, e.g. blue = decision/gate, green = go/positive, red = critical/stop, amber = caution (throttle/fallback/backoff), purple = interactive.

## 3. Build the flow as a real flowchart
- Centre the main spine on one vertical axis; branches exit clean left/right.
- Consistent vertical rhythm (~120px between rows).
- Diamonds = decisions, rounded rectangles = steps/notes, squares = outcomes/cells.
- The logic that makes the feature SAFE (a backoff / cap / suppression gate) must sit IN the flow path, not only as a side note.
- Surface the hardest open policy conflict directly on the relevant lane, not buried in a card.

## 4. FigJam via use_figma - mechanics & gotchas
MANDATORY: load the figma-use skill before every use_figma call. FigJam allows ShapeWithText + Connector; design-mode node types are blocked.
- Notes = a SINGLE self-contained ShapeWithText rounded-rectangle. NEVER a section + child text nodes: the child text re-parents and the section renders empty.
- Load Inter (Regular/Medium) in try/catch before setting any .text.characters.
- Colours are 0-1 RGB; no alpha inside the color object (opacity is a paint-level field).
- Connector cap is connectorEndStrokeCap (not connectorEndCap). Endpoints are connectorStart/connectorEnd = {endpointNodeId, magnet}. Set explicit magnets (LEFT/RIGHT/TOP/BOTTOM) so branches do not loop. Connectors follow nodes on move, so reposition freely and they re-route.
- Loose card clusters auto-wrap into a SECTION and can absorb or drop a standalone heading text node: let the section name carry the heading, or check after.
- Cross-lane bridges are PAGE-level nodes/connectors, NOT section children. A section reflow leaves them behind and they overlap - always re-check page-level loose nodes after moving a lane.
- Widening a section can push it into a neighbouring section/callout: check for overlap after any resize.
- Tables = grids of ShapeWithText SQUARE cells (no live sort/filter).
- Verify with get_figjam (returns an inline render) after each step; get_screenshot returns only a URL that may not be fetchable. Read back node x/y/w/h to confirm no clip or overlap. use_figma is atomic - on error, stop, read the message, fix, retry.

## 5. Iterate, verify, tidy
- Fold constraints and answers back into the board as you learn them.
- Re-space and align once content stabilises; single ShapeWithText cards are the stable unit.
- Read back / screenshot to confirm nothing clips or overlaps before sharing.

## 6. Record decisions
Keep a living record in memory (/areas/<feature>.md): confirmed decisions with sources, constraints, open questions, board node IDs, and learnings. Update it the same turn a decision changes.

## 7. Produce the review artifacts
From the finished board:
- A review message per audience, pointed at the specific cards each person should weigh in on (share with comment access + DM the link).
- A walkthrough talk-track for the key meeting: framing first, then lane-by-lane, then the decisions to land with owners.

## Definition of done
- One zoned, titled, colour-coded board a reviewer can follow end to end.
- The safety/logic gate is in the flow path; the hardest open decision is visible.
- No clipped text, no overlaps, consistent spacing.
- Confirmed vs Open decisions cards current and source-attributed.
- Living memory record updated.
- Review message + talk-track ready.