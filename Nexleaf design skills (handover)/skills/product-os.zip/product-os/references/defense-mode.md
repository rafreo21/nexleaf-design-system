# Defense Mode — Reviewer Attack & Honest Defense

Load this when the user is preparing for an interview, design critique, stakeholder review, investor pitch, or assessment walkthrough. The goal is not to find more problems — it is to prepare the user to *survive* a hostile read of their work and *defend* the decisions they actually made.

## The shape of the output

Use a Q&A structure. Each entry is:

- **Attack** — the strongest possible reviewer criticism, phrased as that reviewer would phrase it (sharp, direct, sometimes condescending)
- **Honest defense** — what the user can actually say in response. Not a deflection. Not corporate-speak. A real answer that holds up.
- **Concede if true** — if the attack lands, name what should be conceded gracefully instead of defended

Aim for 5–8 attacks. Prioritize the ones most likely to actually come up.

## How to generate the attacks

Ask yourself, as the toughest reviewer in the room:

- What's the most embarrassing question someone could ask?
- What looks like a contradiction in the design / spec / strategy?
- What assumption is being made that the data doesn't actually support?
- What's the obvious alternative the user *didn't* pick, and why didn't they?
- What's the part where prototype quality might be mistaken for production thinking, and how should they pre-empt that?
- What edge case or failure mode would a skeptical engineer ask about first?
- What does "what about X user segment" look like for the worst-case segment?
- What's the part where the user got lucky vs. the part where they were skilled?
- If this fails in 6 months, what will the post-mortem say? Can the user pre-empt that now?

## How to generate the defenses

Defenses should:

- **Acknowledge the kernel of truth.** If the attack has a real point, name it before you push back. Defensive denial signals weakness.
- **Separate heuristic from science.** "We made this call based on heuristics from similar products" is a stronger defense than pretending you had hard data.
- **Name the tradeoff explicitly.** "We chose A over B because of X, accepting Y as a cost" is harder to attack than "A is just better."
- **Cite the boundary.** "This is MVP scope — production would handle this differently" is a legitimate move if accurate.
- **End with conviction.** A defense that ends with "but you might be right" loses. A defense that ends with "and we'd make the same call again" lands.

## What NOT to do in defense mode

- **Do not generate softball attacks.** If the attacks are easy, the defense prep is useless.
- **Do not invent defenses that aren't true.** If the user genuinely doesn't have a good defense, name that and recommend either a concession or a real change to the product.
- **Do not write speeches.** Defenses should be 1–3 sentences. Long defenses sound rehearsed and weak.
- **Do not stack too many attacks.** 5–8 sharp ones beats 15 mediocre ones. The user has to actually internalize them.

## After the Q&A — the synthesis

Close with three things:

1. **The two attacks most likely to come up.** Tell the user where to spend their prep time.
2. **The one concession worth pre-empting.** If something is going to be conceded anyway, the user should bring it up first — it signals self-awareness and disarms the reviewer.
3. **The conviction line.** One sentence the user can return to when pressure mounts. The thing that doesn't change regardless of which attack comes in.

## Conviction protection

The point of defense mode is not to make the user backpedal. It is to make them *unshakeable* on the calls that were actually right, and *gracious* about the ones that weren't.

Great products often exclude some users intentionally. Some risks were taken on purpose. Some simplifications were the correct call. Help the user defend those choices proudly, not apologetically.
