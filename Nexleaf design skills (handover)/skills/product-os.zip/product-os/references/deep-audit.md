# Deep Audit Mode — The 16-Phase Sequence

Load this only when the stakes earn it: complex systems, adaptive products, strategic reviews, high-risk flows, emotionally sensitive products, or decisions with long reversibility cost. For everything else, the lighter modes in SKILL.md are correct.

## How to use this file

Do not mechanically run every phase. The phases are a *menu* — pick the ones that apply to the artifact in front of you, in roughly the order below. If a phase doesn't earn its cost on this specific product, skip it and say you skipped it. A complete deep audit usually touches 8–12 phases, not all 16.

End the audit with a converged decision. The phases produce raw material; synthesis is the deliverable.

---

## Phase -1 — Opportunity Expansion (before critique)

Before any critique, generate alternatives. What would a *surprisingly better* approach look like? What would most competitors build, and could the opposite work? Could a simpler solution outperform the smartest one? What would make this genuinely memorable?

Do not skip this. Skipping it makes the whole audit feel punitive.

## Phase 0 — Decision Constraints

Define before analyzing: project type, business context, timeline, fidelity expectations, technical constraints, stakeholder pressure, success criteria, validation goal, MVP boundary, what "good enough" means.

Ask: What actually needs to be proven? What is the highest-risk assumption? What is intentionally NOT being solved? What level of rigor is appropriate?

This phase prevents you from auditing a Wednesday-afternoon prototype against production standards.

## Phase 1 — Problem Understanding

Identify the obvious problem, the deeper emotional problem, the behavioral problem, the trust problem, and the business problem. Often these are four different problems wearing the same name.

Then surface: hidden stakeholder assumptions, misleading metrics, emotional rejection risks, adoption risks, anti-patterns likely to fail, contradictions in the requirements.

## Phase 2 — UX Exploration

Generate 3 *fundamentally different* UX approaches. For each: core idea, why it might work, emotional risks, business risks, implementation complexity, long-term implications.

Critique each honestly. Identify which organizations could realistically execute it. Then recommend the strongest direction and explain what you rejected and why.

Optimize for emotional acceptance, behavioral realism, product clarity, trust, implementation feasibility, and strategic leverage — not novelty alone.

## Phase 2.5 — Core Product Bet

Before MVP scoping, name the bet. What is the strongest differentiator? What makes this hard to copy? What creates real advantage? What would users remember? What should NOT be simplified away?

This phase exists to protect originality from being critiqued out of the product.

## Phase 3 — Behavioral Product Logic

Define user behavior states, adaptation logic, escalation systems, intervention systems, anti-gaming behavior, trust-preserving behavior, emotional recovery systems.

Ask: How can users fake success? How can metrics become misleading? How can adaptation become manipulative? What creates distrust? What feels punitive? What causes disengagement?

## Phase 3.5 — Human Chaos Check

Assume users are distracted, irrational, emotional, impatient, inconsistent, social, tired, and unpredictable. Ask: What irrational behavior breaks this? What shortcuts will users invent? What social behavior changes this? What happens under stress or distraction? What happens if users misuse the system intentionally?

## Phase 4 — MVP Discipline

Aggressively separate: true MVP requirements, future platform ideas, speculative systems, unnecessary complexity, "nice-to-have" features.

Ask: What must exist to validate the idea? What is over-engineering? What can be removed entirely? Could a simpler solution work well enough?

Complexity must earn its existence.

## Phase 5 — Business Pressure Audit

Critique implementation cost, scalability, operational burden, onboarding friction, maintenance cost, support overhead, time-to-value, organizational friction.

Ask: Would a real business prioritize this? Would engineering support this? Would this survive roadmap pressure? Is this operationally realistic?

## Phase 5.5 — Organizational Reality Audit

Critique stakeholder alignment risk, ownership ambiguity, political resistance, executive misunderstanding, dependency bottlenecks, team coordination risk.

Ask: Who could block this internally? Which team would resist this? What incentives conflict here?

## Phase 6 — Adoption & Distribution Audit

Critique onboarding friction, activation barriers, retention loops, discoverability, switching costs, repeat motivation, habit formation.

Ask: Why would users continue using this? What creates repeat behavior? What happens after novelty fades? What makes this sticky?

## Phase 7 — Validation Framework

For every major assumption: state the assumption, rate the risk, name the validation method, design the smallest useful experiment, define measurable success criteria.

Prefer lightweight experiments, behavioral validation, fast learning loops, evidence over speculation.

## Phase 8 — Implementation Pressure Test

Critique architecture integrity, state logic, behavioral consistency, adaptive logic, edge cases, emotional consistency, implementation contradictions, fake sophistication, misleading summaries, trust-breaking behavior.

Classify findings:
- **P0** = credibility-breaking
- **P1** = major UX/business risk
- **P2** = meaningful polish issue
- **P3** = acceptable MVP simplification

Do not confuse prototype limitations with production failures.

## Phase 9 — Emotional UX Audit

Critique shame risk, confidence erosion, emotional fatigue, manipulative adaptation, patronizing language, fake progress, failure escalation, trust transparency.

Ask: Does this preserve dignity? Does this feel respectful? Does this feel believable? Does this punish mistakes emotionally?

## Phase 9.5 — Taste & Resonance Check

Ask: Does this feel emotionally memorable? Does this create delight or only correctness? Does this feel alive or mechanically optimized? Would users describe this positively? Does this create emotional resonance? Would this stand out culturally?

Strategically correct products can still feel emotionally flat. Name it when they do.

## Phase 10 — Defense Preparation

Generate the strongest reviewer criticisms, attack questions, contradiction risks, weak assumptions, implementation credibility gaps. Then generate honest defense answers. Explain tradeoffs clearly. Separate heuristics from validated science. Explain MVP vs production boundaries.

## Phase 10.5 — Conviction Protection

What should remain opinionated? What should NOT be diluted? What makes this uniquely strong? What risks are worth taking intentionally?

Great products often exclude some users intentionally.

## Phase 11 — Prioritization + Ship Gate

Score issues by impact, visibility, trust damage, business risk, user harm. Then ask, for each: would fixing this materially improve usability, trust, retention, conversion, learning, adoption, or demo credibility?

If no — recommend shipping. Define what must be fixed now, what should wait, what should be ignored entirely.

## Phase 11.5 — Momentum Preservation

After critique, identify what is already strong, what should remain untouched, what is working well enough, what should ship confidently.

Prevent endless redesign, critique addiction, fear-driven decisions, permanent dissatisfaction. Preserve momentum, optimism, clarity, decisiveness.

## Phase 12 — Intuition Reflection

Before the final recommendation, ask: What does intuition suggest? What feels directionally right even without complete evidence? What emotional signal matters here? What would an experienced product leader instinctively notice?

Do not over-rationalize everything. If something feels off and you can't articulate why, say that.

## Phase 13 — Synthesis

After the relevant phases:
- Top 3 insights
- Top 3 risks
- Top recommendation
- What matters most
- What should happen next

Always converge toward a clear decision.

## Phase 14 — Product Viability Gate

Explicitly ask: Is this problem important enough? Is the solution materially better? Would users genuinely care? Is this strategically differentiated? Should this idea be simplified drastically? Should this idea be abandoned entirely?

"Do not build this" is a valid conclusion.

## Phase 15 — Energy Calibration

Maintain pressure, optimism, momentum, clarity, conviction. Avoid creating fear-driven teams, critique addiction, permanent skepticism, emotionally drained decision-making.

Honest pressure + forward momentum is the goal, not exhaustion.

## Phase 16 — Final Verdict

Rate (1–5 or qualitative): product thinking, UX quality, emotional intelligence, implementation credibility, MVP discipline, business realism, strategic clarity, innovation quality, trustworthiness.

Then explain: the real strengths, the real weaknesses, what makes this senior-level, what still feels immature, what separates it from average work.

---

## Final discipline for deep audits

- Prioritize truth over politeness
- Challenge assumptions aggressively, but not theatrically
- Distinguish strategy from cosmetics
- Distinguish MVP constraints from product flaws
- Optimize for real product effectiveness
- Clarity beats intellectual theater
- Do not mistake sophisticated language for strong thinking
- End with a decision, not a hedge
